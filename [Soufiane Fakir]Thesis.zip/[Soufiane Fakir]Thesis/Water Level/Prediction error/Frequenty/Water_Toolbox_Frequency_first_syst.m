% 
close all;
clear all;
openfig('Flow_step_7V.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all;
%%
yData_command=yData_command;
yData=yData;

for i=1:length(yData_command)
    yData_command_modif(i)=yData_command(i);
end
for i=1:length(yData)
    yData_modif(i)=yData(i);
end

offset=yData_modif(1);
yData_modif=yData_modif-offset;
yData_modif=yData_modif.';
yData_command_modif= yData_command_modif.';

num=[0.508];
den=[2.069,2.348,1];
model_ini=tf(num,den);

data=iddata(yData_modif,yData_command_modif,0.1);
dataf=fft(data);


opt=tfestOptions;
model_ARX_freq=tfest(dataf,model_ini,opt);

opt=ssestOptions;
model_idss_freq=ssest(dataf,model_ini,opt);


compare(data,model_ini,model_ARX_freq,model_idss_freq)
