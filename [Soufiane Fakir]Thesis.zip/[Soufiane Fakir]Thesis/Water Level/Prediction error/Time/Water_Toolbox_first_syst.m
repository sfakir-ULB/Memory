% 
clear all;
openfig('Flow_step_7V.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all;
%%
yData_command=yData_command;
yData=yData;

for i=10:length(yData_command)
    yData_command_modif(i)=yData_command(i);
end
for i=10:length(yData)
    yData_modif(i)=yData(i);
end
yData=yData;

%offset=yData_modif(1);
%yData_modif=yData_modif-offset;

yData_modif=yData_modif.';
yData_command_modif= yData_command_modif.';


num=[0.508];
den=[2.069,2.348,1];
model_ini=tf(num,den);


data=iddata(yData_modif,yData_command_modif,0.1);

opt=tfestOptions;
model_ARX=tfest(data,model_ini,opt);

opt=ssestOptions;
model_idss=ssest(data,model_ini,opt);

opt=polyestOptions;
poly_ini=[1,1,1,2,2,0];
model_poly=polyest(data,poly_ini,opt);



compare(data,model_ini,model_ARX,model_idss,model_poly)