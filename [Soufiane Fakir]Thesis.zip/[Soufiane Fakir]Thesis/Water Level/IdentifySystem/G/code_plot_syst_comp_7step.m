figure;
plot(xData,yData_command,'g',xData,yData,'b',xData,yData_2,'r');
xlabel('Time [sec]');ylabel('Tension[V]');title('Water Flow rate and Water Level for a step signal of 7V ');
legend('Input signal','Water Flow rate','Water Level')