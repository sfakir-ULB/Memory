%% 
clear all;
openfig('Flow_regulation_5V_K1.5.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
%yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all
%%
openfig('Water_Level_regulation_5V_K1.5.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData_2=cell2mat(y(2));
close all
%%
yData_modif=yData;
yData_modif_2=yData_2;

offset=yData(1);
offset_2=yData_2(1);
yData_modif=yData_modif-offset;
yData_modif_2=yData_modif_2-offset_2;
yData_modif=yData_modif.';
yData_modif_2=yData_modif_2.';

dt = 1;
ud = yData_modif(1:dt:end); 
yd = yData_modif_2(1:dt:end);  
T = xData(1:dt:end);
time=1:dt:dt*T;
%% input of the Low rank method
w = [ud yd];
m=1;
ell=1;
opt_oe.wini = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
[model_LR, info, wh] = ident(w, m, ell, opt_oe); 
model_LR.Ts=0.1;
yh = wh(:, 2);

%% compare
data=iddata(yd,ud,0.1); 
compare(data,model_LR);