
openinout; %Initialisation

Tcycle=0.05;%sampling time

lengthExp=15;%longueur de l'experience

N0=lengthExp/Tcycle; % Nombre de donn�e acquise


Data=zeros(N0,3); %initialisation des matrice ou les donn�es seront stock�e
DataCommands=zeros(N0,1);


cond=1; %Condition pour rester dans la boucle
i=1; %counter initialisation


input=0; %Initialise input of the inner loop
ref=1.8; %valeur du step
K1=4; %Proportional regulateur value 
DataCommands(:)=ref;

actuator=zeros(N0,1);
%%%%%%%%%Loop%%%%%%%%%%%

while cond==1
    tic
    [in1,in2]=anain; %Anain fonction qui lit les mesures
   
    error_inner=ref-in1; %Error inner loop
    input=K1*error_inner;
    
    
    
    
    
    if input>3 %saturation
        input=3;
    elseif input<-1
        input=-1;
    end
    
    
    actuator(i,1)=input;
    %Variable ou on stock les donn�es
    Data(i,1)=in1;
    Data(i,2)=in2;
    
    i=i+1;
    t=toc;
%%%%%%%Verification du temps de sampling%%%%%%%%    
   

anaout(input,0); %fonction qui permet d'appliquer la tension desir� dans la carte de sortie 


if t>Tcycle
        disp('Sampling time too small');
    else
        while toc<=Tcycle
        end
    end
    
%%%%%% Condition de stop%%%%%%%%%%

    if i==N0+1
        cond=0;
    end
    
end

%%%%%%%%Plot%%%%%%%%%
closeinout
i=i-1;
time=0:Tcycle:(i-1)*Tcycle;

figure
plot(time,Data(:,1),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension[V]');title('Fan velocity for a step signal of 2.5V Measurement Gain [2.5V = 1000rpm] with a proportional regulator [K=5] ');
figure
plot(time,Data(:,2),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension[V]');title('Ball position for  a step signal of 2.3V with a proportional regulator [K=5]');