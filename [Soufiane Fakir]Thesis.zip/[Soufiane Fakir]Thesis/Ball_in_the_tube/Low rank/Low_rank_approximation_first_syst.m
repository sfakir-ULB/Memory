%% Data recovery from graph
clear all;
openfig('Fan_velocity_step_3V.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
%x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
%xData=cell2mat(x(1));
close all
%% Data processing 
yData_command=yData_command.';
yData=yData.';
offset=yData(1);
yData=yData-offset;
data=iddata(yData,yData_command,0.1); 

dt = 1;
ud = yData_command(1:dt:end);
yd = yData(1:dt:end);
T = length(ud);
time=1:dt:dt*T;

%% input of the Low rank method
w = [ud yd];
m=1;
ell=1;
opt_oe.wini   = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
[model_LR, info, wh] = ident(w, m, ell, opt_oe); 
model_LR.Ts=0.05;
yh = wh(:, 2);
%% comparison 
%plot(ud, 'g--'), hold on, plot(yd, 'k--'),plot(yh, 'b')
%xlabel('Time [sec]');ylabel('Tension[V]');title('Simulation : Fan velocity for a step signal of 3V ');legend('Input signal','Response','Simulation')
%% compare
data=iddata(yd,ud,0.05); 
compare(data,model_LR);