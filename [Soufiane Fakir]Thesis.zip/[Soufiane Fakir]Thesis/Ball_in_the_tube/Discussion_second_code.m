% %% first model 
warning off
close all;
clear all;
openfig('Fan_velocity_step_2.5V.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';
offset=yData(1);
yData=yData-offset;
num=[3.250];
den=[0.370,1];
model_ini=tf(num,den);

data=iddata(yData,yData_command,0.025);
%%%%%%%%%% Frequenty
dataf=fft(data);

opt=ssestOptions;
model_idss_freq=ssest(dataf,model_ini,opt);

opt=tfestOptions;
model_ARX_freq=tfest(dataf,model_ini,opt);
%%%%%%%%%%%%%%%%%%pem

opt=tfestOptions;
model_ARX=tfest(data,model_ini,opt);

opt=ssestOptions;
model_idss=ssest(data,model_ini,opt);

opt=polyestOptions;
poly_ini=[1,1,0,1,1,0];
model_poly=polyest(data,poly_ini,opt);

%%%%%%%%%%%%%%Low rank 
dt = 1;
ud = yData_command(1:dt:end);
yd = yData(1:dt:end); 
T = length(ud);
time=1:dt:dt*T;

w = [ud yd];
m=1;
ell=1;
opt_oe.wini = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
tic;[model_LR, info, wh] = ident(w, m, ell, opt_oe);time_LR=toc;
model_LR.Ts=0.025;

model_LR=idss(model_LR);
model_LR=d2c(model_LR);
model_LR=c2d(model_LR,0.025);

%% second model


openfig('Fan_velocity_step_66V_K10.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
%yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all;

openfig('Ball_position_step_66V_regulated_converted.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData_2=cell2mat(y(2));
close all

yData_modif=[];
yData_modif_2=[];
for i=30 : 530
    yData_modif(i-29)=yData(i);
end
for i=30 : 530
    yData_modif_2(i-29)=yData_2(i);
end


yData_modif=yData_modif.';
yData_modif_2=yData_modif_2.';

%offset=yData(1);
offset_2=yData_modif_2(1);
%yData_modif=yData_modif-offset;
yData_modif_2=yData_modif_2-offset_2;

num=-1.19;
den=[1 0];
model_ini_2=tf(num,den);


data=iddata(yData_modif_2,yData_modif,0.025);

%%%%freq
num=-1.19;
den=[1 1];
model_ini_3=tf(num,den);

dataf=fft(data);

opt=tfestOptions;
model_ARX_freq_2=tfest(dataf,model_ini_3,opt);

opt=ssestOptions('EnforceStability',true);
model_idss_freq_2=ssest(dataf,model_ini_3,opt);

%%%%%pem
opt=tfestOptions;
model_ARX_2=tfest(data,model_ini_2,opt);

opt=ssestOptions;
model_idss_2=ssest(data,model_ini_2,opt);

opt=polyestOptions;
poly_ini_2=[1,1,1,1,1,0];
model_poly_2=polyest(data,poly_ini_2,opt);
%%%%%%%%% Low Rank

dt = 1;
ud = yData_modif(1:dt:end); 
yd = yData_modif_2(1:dt:end); 
T = length(ud);
time=1:dt:dt*T;

w = [ud yd];
m=1;
ell=1;
opt_oe.wini = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
tic;[model_LR_2, info, wh] = ident(w, m, ell, opt_oe);time_LR_2=toc; 
model_LR_2.Ts=0.025;
model_LR_2=idss(model_LR_2);
model_LR_2=d2c(model_LR_2);
model_LR_2=c2d(model_LR_2,0.025);

%% comparison train data
opt = compareOptions('InitialCondition','z');
compare(data,model_ini_2,model_ARX_2,model_idss_2,model_poly_2,model_ARX_freq_2,model_idss_freq_2,opt)

%% Building system
system_ARX_freq =series(model_ARX_freq,model_ARX_freq_2);
system_idss_freq =series(model_idss_freq,model_idss_freq_2);
system_LR =series(model_LR,model_LR_2);
system_poly =series(model_poly,model_poly_2);
system_idss =series(model_idss,model_idss_2);
system_ARX =series(model_ARX,model_ARX_2);
system_ini =series(model_ini,model_ini_2);

%% comparison validation data ramp 
close all;

openfig('Ball_position_ramp_1Vto4V_converted.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
close all

yData_modif=[];
yData_modif_2=[];
for i=400 : 510
    yData_modif(i-399)=yData_command(i);
end
for i=400 : 510
    yData_modif_2(i-399)=yData(i);
end


yData_modif=yData_modif.';
yData_modif_2=yData_modif_2.';

%offset=yData(1);
offset_2=yData_modif_2(1);
%yData_modif=yData_modif-offset;
yData_modif_2=yData_modif_2-offset_2;

data_val=iddata(yData_modif_2,yData_modif,0.025);
opt = compareOptions('InitialCondition','z');
[Yh,M_ramp]=compare(data_val,system_ini,system_ARX,system_idss,system_poly,system_LR,system_idss_freq,system_ARX_freq,opt)


%% comparison validation data curve 
close all;

openfig('Ball_position_curve_1Vto4V_converted.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
close all

yData_modif=[];
yData_modif_2=[];
for i=300 : 370
    yData_modif(i-299)=yData_command(i);
end
for i=300 : 370
    yData_modif_2(i-299)=yData(i);
end

yData_modif=yData_modif.';
yData_modif_2=yData_modif_2.';

%offset=yData(1);
offset_2=yData_modif_2(1);
%yData_modif=yData_modif-offset;
yData_modif_2=yData_modif_2-offset_2;

data_val=iddata(yData_modif_2,yData_modif,0.025);
opt = compareOptions('InitialCondition','z');
[Yh,M_curve]=compare(data_val,system_ini,system_ARX,system_idss,system_poly,system_LR,system_idss_freq,system_ARX_freq,opt)

%% computing time with same data

data=iddata(yd,ud,0.025); 

SystemOrder=[0 1];
ud=ud.';
yd=yd.';
tic;sysIdent=IdentifySystem(ud,yd,SystemOrder,0.025);time_nonlinear_2=toc;

opt=tfestOptions;
tic;model_ARX_2=tfest(data,model_ini,opt);time_ARX_2=toc;

opt=ssestOptions;
tic;model_idss_2=ssest(data,model_ini,opt);time_idss_2=toc;

opt=polyestOptions;
poly_ini=[1,0,1,1,1,0];
tic;model_poly_2=polyest(data,poly_ini,opt);time_poly_2=toc;
