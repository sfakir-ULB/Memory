figure;
plot(xData,yData_command,'g',xData,yData,'b',xData,yData_2,'r');
xlabel('Time [sec]');ylabel('Tension[V]  Distance[cm]');title('Velocity of the Fan and Ball position for a step signal of 2.5V ');
legend('Input signal','Fan Velocity','Ball Position')