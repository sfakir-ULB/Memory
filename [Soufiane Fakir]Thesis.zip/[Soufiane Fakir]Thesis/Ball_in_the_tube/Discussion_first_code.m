%% Train data
warning off
close all;
clear all;
openfig('Fan_velocity_step_2.5V.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';
offset=yData(1);
yData=yData-offset;
num=[3.250];
den=[0.370,1];
model_ini=tf(num,den);

data=iddata(yData,yData_command,0.05);
%%%%%%%%%% Frequenty
dataf=fft(data);

opt=ssestOptions;
model_idss_freq=ssest(dataf,model_ini,opt);

opt=tfestOptions;
model_ARX_freq=tfest(dataf,model_ini,opt);
%%%%%%%%%%%%%%%%%%pem

opt=tfestOptions;
model_ARX=tfest(data,model_ini,opt);

opt=ssestOptions;
model_idss=ssest(data,model_ini,opt);

opt=polyestOptions;
poly_ini=[1,1,0,1,1,0];
model_poly=polyest(data,poly_ini,opt);

%%%%%%%%%%%%%%Low rank 
dt = 1;
ud = yData_command(1:dt:end);
yd = yData(1:dt:end); 
T = length(ud);
time=1:dt:dt*T;

w = [ud yd];
m=1;
ell=1;
opt_oe.wini = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
tic;[model_LR, info, wh] = ident(w, m, ell, opt_oe);time_LR=toc;
model_LR.Ts=0.05;

model_LR=idss(model_LR);
model_LR=d2c(model_LR);
model_LR=c2d(model_LR,0.05);
%% comparison Train data 

opt = compareOptions('InitialCondition','z');
[Yh,M_step]=compare(data,model_ini,model_ARX,model_idss,model_poly,model_LR,opt,model_idss_freq, model_ARX_freq)

%% comparison validation data ramp
close all;
openfig('Fan_velocity_ramp_1Vto4V.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';

%offset=yData_command(1);
%yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.05);
opt = compareOptions('InitialCondition','z');
[Yh,M_ramp]=compare(data_val,model_ini,model_ARX,model_idss,model_poly,model_LR,model_idss_freq, model_ARX_freq,opt)


 %% comparison validation data curve

close all;
openfig('Fan_velocity_curve_0Vto9V.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_modif=[];
yData_modif_2=[];
for i=1 : 350
    yData_modif(i)=yData_command(i);
end
for i=1 : 350
    yData_modif_2(i)=yData(i);
end

yData_command=yData_modif.';
yData=yData_modif_2.';


offset=yData_command(1);
yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.05);
opt = compareOptions('InitialCondition','z');
[Yh,M_curve]=compare(data_val,model_ini,model_ARX,model_idss,model_poly,model_LR,model_idss_freq, model_ARX_freq,opt)

%% comparison validation data sinusoid

close all;
openfig('Fan_velocity_sinusoid_0.5.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';

%offset=yData_command(1);
%yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.05);
opt = compareOptions('InitialCondition','z');
[Yh,M_sinusoid]=compare(data_val,model_ini,model_ARX,model_idss,model_poly,model_LR,opt,model_idss_freq, model_ARX_freq)

 %% computing time with same data
data=iddata(yd,ud,0.05); 

SystemOrder=[0 1];
ud=ud.';
yd=yd.';
tic;sysIdent=IdentifySystem(ud,yd,SystemOrder,0.05);time_nonlinear=toc;

opt=polyestOptions;
poly_ini=[1,1,0,1,1,0];
tic;model_poly=polyest(data,poly_ini,opt);time_polyest=toc;

opt=tfestOptions;
tic;model_ARX=tfest(data,model_ini,opt);time_tfest=toc;

opt=ssestOptions;
tic;model_idss=ssest(data,model_ini,opt);time_ssest=toc;