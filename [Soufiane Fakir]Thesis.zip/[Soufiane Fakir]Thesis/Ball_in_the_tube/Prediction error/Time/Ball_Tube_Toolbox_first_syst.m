%% 
clear all;
openfig('Fan_velocity_step_2.5V.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all;
%%
yData_command=yData_command.';
yData=yData.';

offset=yData(1);
yData=yData-offset;
num=[3.250];
den=[0.370,1];
model_ini=tf(num,den);

data=iddata(yData,yData_command,0.05);

opt=tfestOptions;
model_ARX=tfest(data,model_ini,opt);

opt=ssestOptions;
model_idss=ssest(data,model_ini,opt);

opt=polyestOptions;
poly_ini=[1,1,0,1,1,0];
model_poly=polyest(data,poly_ini,opt);



compare(data,model_ini,model_ARX,model_idss,model_poly)