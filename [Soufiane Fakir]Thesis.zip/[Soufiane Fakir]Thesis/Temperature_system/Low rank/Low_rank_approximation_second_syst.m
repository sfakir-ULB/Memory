%%  
clear all;
openfig('Pipe_temperature_step5V_K5.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData=cell2mat(y(2));

close all
%%
openfig('Air_temperature_step5V_K5.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData_2=cell2mat(y(2));
close all
%% Data processing
yData=yData.';
yData_2=yData_2.';
%offset=yData(1);
offset_2=yData_2(1);
%yData=yData-offset;
yData_2=yData_2-offset_2;

data=iddata(yData_2,yData,0.1);
dt = 20;
ud = yData(1:dt:end); 
yd = yData_2(1:dt:end); 
T = length(ud);
time=1:dt:dt*T;

%% input of the Low rank method
w = [ud yd];
m=1;
ell=2;
opt_oe.wini = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
[model_LR, info, wh] = ident(w, m, ell, opt_oe); 
model_LR.Ts=0.1;
yh = wh(:, 2);
%% plot
%plot(ud, 'g--'), hold on, plot(yd, 'k--'),plot(yh, 'b');
%xlabel('Time [sec]');ylabel('Tension[V]');title('Simulation : Air temperature for a step signal of 5V ');legend('Input signal','Response','Simulation');
%% compare
data=iddata(yd,ud,0.1); 
compare(data,model_LR);