%%%%%%%%%%%%%%%%%%%All first system model
clear all
openfig('Step_response_4V_pipe_temperature.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';
offset=yData(1);
yData=yData-offset;
num=[1.061];
den=[6004.24,263.37,1];
model_ini=tf(num,den);

data=iddata(yData,yData_command,0.1);
%%%%%%%%%% Frequenty
dataf=fft(data);

opt=ssestOptions;
model_idss_freq=ssest(dataf,model_ini,opt);

opt=tfestOptions;
model_ARX_freq=tfest(dataf,model_ini,opt);
%%%%%%%%%%%%%%%%%%pem

opt=tfestOptions;
model_ARX=tfest(data,model_ini,opt);

opt=ssestOptions;
model_idss=ssest(data,model_ini,opt);

opt=polyestOptions;
poly_ini=[1,1,1,2,2,0];
model_poly=polyest(data,poly_ini,opt);

%%%%%%%%%%%%%%Low rank 
dt = 5;
ud = yData_command(1:dt:end);
yd = yData(1:dt:end); 
T = length(ud);
time=1:dt:dt*T;

w = [ud yd];
m=1;
ell=2;
opt_oe.wini = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
tic;[model_LR, info, wh] = ident(w, m, ell, opt_oe);time_LR=toc;
model_LR.Ts=0.5;

model_LR=idss(model_LR);
model_LR=d2c(model_LR);
model_LR=c2d(model_LR,0.1);




%% Train data

%%%%%%%%%% second model %%%%

warning off
close all;

openfig('Pipe_temperature_step5V_K5.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData=cell2mat(y(2));
close all;

openfig('Air_temperature_step5V_K5.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData_2=cell2mat(y(2));
close all
%%
yData=yData.';
yData_2=yData_2.';
%offset=yData(1);
offset_2=yData_2(1);
%yData=yData-offset;
yData_2=yData_2-offset_2;

num=[1.073];
den=[0.819,226.535,1];
model_ini_2=tf(num,den);

data=iddata(yData_2,yData,0.1);

%%%%%%freqency
dataf=fft(data);

opt=tfestOptions;
model_ARX_freq_2=tfest(dataf,model_ini,opt);

opt=ssestOptions;
model_idss_freq_2=ssest(dataf,model_ini,opt);

%%%%%%%pem

opt=tfestOptions;
model_ARX_2=tfest(data,model_ini,opt);

opt=ssestOptions;
model_idss_2=ssest(data,model_ini,opt);

opt=polyestOptions;
poly_ini=[1,1,1,2,2,0];
model_poly_2=polyest(data,poly_ini,opt);

%%%%%%Low rank
dt = 15;
ud = yData(1:dt:end); 
yd = yData_2(1:dt:end); 
T = length(ud);
time=1:dt:dt*T;

w = [ud yd];
m=1;
ell=2;
opt_oe.wini = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
tic;[model_LR_2, info, wh] = ident(w, m, ell, opt_oe);time_LR=toc;
model_LR_2.Ts=1.5;

model_LR_2=idss(model_LR_2);
model_LR_2=d2c(model_LR_2);
model_LR_2=c2d(model_LR_2,0.1);
%% comparison Train data 

opt = compareOptions('InitialCondition','z');
[Yh,M_step]=compare(data,model_ini_2,model_ARX_2,model_idss_2,model_poly_2,model_LR_2,model_idss_freq_2, model_ARX_freq_2,opt);

%% Building system
system_ARX_freq =series(model_ARX_freq,model_ARX_freq_2);
system_idss_freq =series(model_idss_freq,model_idss_freq_2);
system_LR =series(model_LR,model_LR_2);
system_poly =series(model_poly,model_poly_2);
system_idss =series(model_idss,model_idss_2);
system_ARX =series(model_ARX,model_ARX_2);
system_ini =series(model_ini,model_ini_2);

%% comparison validation data ramp
close all;
openfig('ramp_response_2Vto6V_Air_temperature.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';

%offset=yData_command(1);
%yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.1);
opt = compareOptions('InitialCondition','z');
[Yh,M_sys_ramp]=compare(data_val,system_ini,system_ARX,system_idss,system_poly,system_LR,system_idss_freq,system_ARX_freq,opt)

%% comparison validation data ramp
close all;
openfig('curve_response_0Vto16V_Air_temperature.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';

offset=yData_command(1);
yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.1);
opt = compareOptions('InitialCondition','z');
[Yh,M_sys_curve]=compare(data_val,system_ini,system_ARX,system_idss,system_poly,system_LR,system_idss_freq,system_ARX_freq,opt)



%% comparison validation data sinusoid

close all;
openfig('sinusoid_response_Air_temperature.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';

%offset=yData_command(1);
%yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.1);
opt = compareOptions('InitialCondition','z');
[Yh,M_sys_sinusoid]=compare(data_val,system_ini,system_ARX,system_idss,system_poly,system_LR,system_idss_freq,system_ARX_freq,opt)

%% computing time with same data

data=iddata(yd,ud,1.5); 

SystemOrder=[0 2];
ud=ud.';
yd=yd.';
tic;sysIdent=IdentifySystem(ud,yd,SystemOrder,1.5);time_nonlinear_2=toc;

opt=tfestOptions;
tic;model_ARX_2=tfest(data,model_ini,opt);time_ARX_2=toc;

opt=ssestOptions;
tic;model_idss_2=ssest(data,model_ini,opt);time_idss_2=toc;

opt=polyestOptions;
poly_ini=[1,1,1,2,2,0];
tic;model_poly_2=polyest(data,poly_ini,opt);time_poly_2=toc;

