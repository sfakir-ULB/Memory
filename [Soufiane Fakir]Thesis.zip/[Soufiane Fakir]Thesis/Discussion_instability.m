%% generate data
clear all, randn('seed', 0), rand('seed', 0), warning off
m = 1; p = 1; ell = 2; T = 300; s = 0.1;     
opt_oe.exct = 1:m; % fixed inputs = output error identification
opt_eiv.exct = []; % errors-in-variables setup 


n = ell * p; q = m + p; sys0 = drss(n, p, m); % random  system sys0
u0 = rand(T, m); xini0 = rand(n, 1);          % random  input u0
y0 = lsim(sys0, u0, [], xini0); u = u0;       % generate output y0 from random u0, random sys0
w0 = [u0 y0]; 

%% Build system  with the different method

SystemOrder=[0 2];

u01=u0.';
y01=y0.';

Syst=IdentifySystem(u01,y01,SystemOrder,1);
a=cell2mat(Syst.Numerator(1,:));
b=cell2mat(Syst.Denominator(1,:));
[A,B,C,D]=tf2ss(a,b);
Syst_ss=ss(A,B,C,D);

poly_ini=[1,1,1,0,0,0];
model_poly=polyest(iddata(y0, u0),poly_ini);

model_ARX=tfest(iddata(y0,u0),Syst);
a=model_ARX.Numerator;
b=model_ARX.Denominator;
[A,B,C,D]=tf2ss(a,b);
model_ARX_ss=ss(A,B,C,D);


model_idss=ssest(iddata(y0,u0),Syst);

sysh_ident = ident(w0, m, ell, opt_oe);

eig0=eig(sys0);
eig1=eig(Syst_ss) ;
eig2=eig(model_ARX_ss) ; 
eig3=eig(model_idss); 
eig4=eig(model_poly) ;
eig5=eig(sysh_ident);



try
 Syst_flip=IdentifySystem(flipud(u01),flipud(y01),SystemOrder,1);
 a=cell2mat(Syst.Numerator(1,:));
 b=cell2mat(Syst.Denominator(1,:));
 [A,B,C,D]=tf2ss(a,b);
 Syst_ss_flip=ss(A,B,C,D);
 catch
 Syst_ss_flip=zeros(n);
 end
try
opt=polyestOptions;
opt.Advanced.StabilityThreshold.z = inf;
opt.Advanced.StabilityThreshold.s = inf;
poly_ini=[2,1,2,0,0,0];
model_poly_flip=polyest(iddata(flipud(y0),flipud(u0)),poly_ini,opt);
catch
model_poly_flip=zeros(n); 
end

try
opt=tfestOptions;
opt.Advanced.StabilityThreshold.z = inf;
opt.Advanced.StabilityThreshold.s = inf;
model_ARX=tfest(iddata(flipud(y0),flipud(u0)),2);
a=model_ARX.Numerator;
b=model_ARX.Denominator;
[A,B,C,D]=tf2ss(a,b);
model_ARX_ss_flip=ss(A,B,C,D);
catch
    model_ARX_ss_flip=zeros(n);
end

try
opt=ssestOptions;
opt.Advanced.StabilityThreshold.z = inf;
opt.Advanced.StabilityThreshold.s = inf;
model_idss_flip=ssest(iddata(flipud(y0),flipud(u0)),2,opt);
catch
model_idss_flip=zeros(n);
end

sysh_ident_flip = ident(flipud(w0), m, ell, opt_oe);


eigf1=eig(Syst_ss_flip) ;
eigf2=eig(model_ARX_ss_flip) ; 
eigf3=eig(model_idss_flip); 
eigf4=eig(model_poly_flip) ;
eigf5=eig(sysh_ident_flip);

R0=sort(1 ./ eig0) ; 

R1f = real(sort(eigf1)); 

R2f = real(sort(eigf2)); 

R3f = real(sort(eigf3)); 

R4f = real(sort(eigf4)); 

R5f = real(sort(eigf5)); 


R=[sort(R0) sort(R1f) sort(R2f) sort(R3f) sort(R4f) sort(R5f)];
