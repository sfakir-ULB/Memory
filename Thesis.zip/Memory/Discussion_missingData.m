%% Train data
warning off
close all;
clear all;
openfig('Step_response_4V_pipe_temperature.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';
offset=yData(1);
yData=yData-offset;

%%
dt = 150;
ud = yData_command(1:dt:end);
yd = yData(1:dt:end); 
T = length(ud);
time=1:dt:dt*T;

data=iddata(yd,ud,15); 
%%%%lowrank
w = [ud yd];
m=1;
ell=2;
opt_oe.wini = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
tic;[model_LR, info, wh] = ident(w, m, ell, opt_oe);time_LR=toc;
model_LR.Ts=15;
model_LR=idss(model_LR);


SystemOrder=[0 2];
ud=ud.';
yd=yd.';
tic;model_ini=IdentifySystem(ud,yd,SystemOrder,15);time_nonlinear=toc;
%%%%%pem
opt=polyestOptions;
poly_ini=[1,1,1,2,2,0];
tic;model_poly=polyest(data,poly_ini,opt);time_polyest=toc;

opt=tfestOptions;
tic;model_ARX=tfest(data,model_ini,opt);time_tfest=toc;

opt=ssestOptions;
tic;model_idss=ssest(data,model_ini,opt);time_ssest=toc;
%%%%%%freq%%%%
dataf=fft(data);

opt=ssestOptions;
model_idss_freq=ssest(dataf,model_ini,opt);

opt=tfestOptions;
model_ARX_freq=tfest(dataf,model_ini,opt);

%% comparison step
opt = compareOptions('InitialCondition','z');
[Yh,M_step]=compare(data,model_ini,model_ARX,model_idss,model_poly,model_LR,model_idss_freq, model_ARX_freq,opt)

%% comparison validation data ramp
close all;
openfig('ramp_response_2Vto6V_Pipe_temperature.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';

%offset=yData_command(1);
%yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.1);
model_LR=d2c(model_LR);
model_LR=c2d(model_LR,0.1);
model_poly=d2c(model_poly);
model_poly=c2d(model_poly,0.1);



opt = compareOptions('InitialCondition','z');
[Yh,M_ramp]=compare(data_val,model_ini,model_ARX,model_idss,model_poly,model_LR,opt,model_idss_freq, model_ARX_freq)

%%
close all;
openfig('curve_response_0Vto16V_Pipe_temperature.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';

%offset=yData_command(1);
%yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.1);

opt = compareOptions('InitialCondition','z');
[Yh,M_curve]=compare(data_val,model_ini,model_ARX,model_idss,model_poly,model_LR,opt,model_idss_freq, model_ARX_freq)

