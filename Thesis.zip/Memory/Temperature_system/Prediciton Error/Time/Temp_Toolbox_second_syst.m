%% 
close all;
clear all;
openfig('Pipe_temperature_step5V_K5.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
%yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
%xData=cell2mat(x(1));
close all;
%%
openfig('Air_temperature_step5V_K5.fig');
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData_2=cell2mat(y(2));
close all
%%

yData=yData.';
yData_2=yData_2.';
%offset=yData(1);
offset_2=yData_2(1);
%yData=yData-offset;
yData_2=yData_2-offset_2;
%%
num=[1.073];
den=[0.819,226.535,1];
model_ini=tf(num,den);

data=iddata(yData_2,yData,0.1);
%%
opt=tfestOptions;
model_ARX=tfest(data,model_ini,opt);

opt=ssestOptions;
model_idss=ssest(data,model_ini,opt);

opt=polyestOptions;
poly_ini=[1,1,1,2,2,0];
model_poly=polyest(data,poly_ini,opt);

compare(data,model_ini,model_ARX,model_idss,model_poly)