openinout; %Initialisation

Tcycle=0.1;%sampling time

lengthExp=800;%longueur de l'experience

N0=lengthExp/Tcycle; % Nombre de donn�e acquise

%initialisation des matrice ou les donn�es seront stock�e
Data=zeros(N0,2);
DataCommands=zeros(N0,1);


cond=1; %Condition pour rester dans la boucle
i=1; %counter initialisation

step=4; %valeur du step

anaout(step,0); %fonction qui permet d'appliquer la tension desir� dans la carte de sortie 

%%%%%%%%%sauvegarde des donn�es%%%%%%%%%%%

while cond==1
    tic
    [in1,in2]=anain; %Anain fonction qui lit les mesures
    
    %Variable ou on stock les donn�es
    Data(i,1)=in1;
    Data(i,2)=in2;
    DataCommands(i,1)=step;
    i=i+1;
    t=toc;
%%%%%%%Verification du temps de sampling%%%%%%%%    
   
if t>Tcycle
        disp('Sampling time too small');
    else
        while toc<=Tcycle
        end
    end
    
%%%%%% Condition de stop%%%%%%%%%%

    if i==N0+1
        cond=0;
    end
    if mod((i*Tcycle),30)==0
        timeElapsed=i*Tcycle
        temperatureSkin=in1
    end
end

%%%%%%%%Plot%%%%%%%%%
closeinout
i=i-1;
time=0:Tcycle:(i-1)*Tcycle;

figure
plot(time,Data(:,1),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension[V]');title('Temperature of the pipe for a step signal of 4V ');
figure
plot(time,Data(:,2),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension[V]');title('Temperature of the air for a step signal of 4V ');