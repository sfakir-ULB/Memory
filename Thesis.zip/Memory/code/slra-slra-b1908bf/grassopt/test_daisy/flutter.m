% Wing flutter data

load flutter.dat
u = flutter(:,1);
y = flutter(:,2);
clear flutter
