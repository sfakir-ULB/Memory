% Heating system

load heating_system.dat
u = heating_system(:,2);
y = heating_system(:,3);
clear heating_system
