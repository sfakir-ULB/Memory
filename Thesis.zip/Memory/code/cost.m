%la cost fonction renvoit la somme des erreurs au carr�

function J = cost(theta)

global u y SystemOrder k
Num = [];
Den = [];
for i = 1 : SystemOrder(1)+1
    Num = [Num theta(1,i)];
end
for j = i+1 : SystemOrder(2)+SystemOrder(1)+1
    Den = [Den theta(1,j)];
end
Den = [Den 1];

sys = tf(Num,Den); %production d'une fonction de transfer au hasard 
hatY = lsim(sys,u,k)'; %simule la reponse du system avec une entr� U 

epsilon = y - hatY; %erreur entre les donn�e et la simulation produit

J = epsilon*epsilon'; %donne un simple nombre qui est somme des erreur aux carr�

