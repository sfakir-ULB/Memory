%% Train data
warning off
close all;
clear all;
openfig('Flow_step_7V.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';
offset=yData(1);
yData=yData-offset;

num=[0.508];
den=[2.069,2.348,1];
model_ini=tf(num,den);

data=iddata(yData,yData_command,0.1);
%%%%%%%%%% Frequenty
dataf=fft(data);

opt=ssestOptions;
model_idss_freq=ssest(dataf,model_ini,opt);

opt=tfestOptions;
model_ARX_freq=tfest(dataf,model_ini,opt);
%%%%%%%%%%%%%%%%%%pem

opt=tfestOptions;
model_ARX=tfest(data,model_ini,opt);

opt=ssestOptions;
model_idss=ssest(data,model_ini,opt);

opt=polyestOptions;
poly_ini=[1,1,1,2,2,0];
model_poly=polyest(data,poly_ini,opt);

%%%%%%%%%%%%%%Low rank 
dt = 1;
ud = yData_command(1:dt:end);
yd = yData(1:dt:end); 
T = length(ud);
time=1:dt:dt*T;

w = [ud yd];
m=1;
ell=2;
opt_oe.wini = 0; % zero initial conditons 
opt_oe.exct = 1; % output error 
tic;[model_LR, info, wh] = ident(w, m, ell, opt_oe);time_LR=toc;
model_LR.Ts=0.1;

model_LR=idss(model_LR);

%% comparison Train data 

opt = compareOptions('InitialCondition','z');
[Yh,M_step]=compare(data,model_ini,model_ARX,model_idss,model_poly,model_LR,model_idss_freq,model_ARX_freq,opt)

%% comparison validation data ramp
close all;
openfig('Flow_ramp_2Vto8V.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';

%offset=yData_command(1);
%yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.1);
opt = compareOptions('InitialCondition','z');
[Yh,M_ramp]=compare(data_val,model_ini,model_ARX,model_idss,model_poly,model_LR,model_idss_freq,opt)


%% comparison validation data curve

close all;
openfig('Flow_curve_4Vto9V.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all

yData_command=yData_command.';
yData=yData.';

%offset=yData_command(1);
%yData_command=yData_command-offset;
offset_2=yData(1);
yData=yData-offset_2;

data_val=iddata(yData,yData_command,0.1);
opt = compareOptions('InitialCondition','z');
[Yh,M_curve]=compare(data_val,model_ini,model_ARX,model_idss,model_poly,model_LR,model_idss_freq, opt)

%% computing time with same data
data=iddata(yd,ud,0.1); 

SystemOrder=[0 2];
ud=ud.';
yd=yd.';
tic;sysIdent=IdentifySystem(ud,yd,SystemOrder,0.5);time_nonlinear=toc;

opt=polyestOptions;
poly_ini=[1,1,1,2,2,0];
tic;model_poly=polyest(data,poly_ini,opt);time_polyest=toc;

opt=tfestOptions;
tic;model_ARX=tfest(data,model_ini,opt);time_tfest=toc;

opt=ssestOptions;
tic;model_idss=ssest(data,model_ini,opt);time_ssest=toc;