yData_pos=[];
for i=1:length(yData)
    yData_pos(i)=volt2height(yData(i));
end

figure
plot(xData,yData_pos,xData,yData_command);
xlabel('Time [sec]');ylabel('Water Level [cm]      Voltage [V]');title('Water level for a curve signal');legend('response','input');




function pos = volt2height(volt)
pos=(13.93*volt)-9.5;

end
