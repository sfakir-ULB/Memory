%% 
close all;
clear all;
openfig('Fan_velocity_step_66V_K10.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
%yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all;
%%
openfig('Ball_position_step_66V_regulated_converted.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData_2=cell2mat(y(2));
close all;
%%
yData_modif=[];
yData_modif_2=[];
for i=30 : 530
    yData_modif(i-29)=yData(i);
end
for i=30 : 530
    yData_modif_2(i-29)=yData_2(i);
end
yData_modif=yData_modif.';
yData_modif_2=yData_modif_2.';

%offset=yData(1);
offset_2=yData_modif_2(1);
%yData_modif=yData_modif-offset;
yData_modif_2=yData_modif_2-offset_2;

num=-1.19;
den=[1 1];
model_ini=tf(num,den);


data=iddata(yData_modif_2,yData_modif,0.025);
dataf=fft(data);

opt=tfestOptions;
model_ARX_freq=tfest(dataf,model_ini,opt);

opt=ssestOptions('EnforceStability',true);
model_idss_freq=ssest(dataf,model_ini,opt);

%opt=polyestOptions;
%poly_ini=[1,1,0,2,2,0];
%model_poly_freq=polyest(dataf,poly_ini,opt);



compare(dataf,model_ini,model_ARX_freq,model_idss_freq)
