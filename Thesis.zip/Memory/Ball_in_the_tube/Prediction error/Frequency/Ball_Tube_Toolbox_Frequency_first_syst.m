%% 
close all;
clear all;
openfig('Fan_velocity_step_2.5V.fig')
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
xData=cell2mat(x(1));
close all;
%%
yData_command=yData_command.';
yData=yData.';
offset=yData(1);
yData=yData-offset;

num=[3.250];
den=[0.370,1];
model_ini=tf(num,den);

data=iddata(yData,yData_command,0.025);
dataf=fft(data);


opt=tfestOptions;
model_ARX_freq=tfest(dataf,model_ini,opt);

opt=ssestOptions;
model_idss_freq=ssest(dataf,model_ini,opt);

%opt=polyestOptions;
%poly_ini=[1,1,0,2,2,0];
%model_poly_freq=polyest(dataf,poly_ini,opt);



compare(dataf,model_ini,model_ARX_freq,model_idss_freq)
