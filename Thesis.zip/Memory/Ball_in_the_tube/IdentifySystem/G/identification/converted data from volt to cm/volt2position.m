yData_pos=[];
for i=1:length(yData)
    yData_pos(i)=volt2pos(yData(i));
end

figure
plot(xData,yData_pos,xData,yData_command);
xlabel('Time [sec]');ylabel('Ball position [cm] ');title('Ball position for a 2.5V step signal ');legend('response','input');




function pos = volt2pos(volt)
pos=0;
if volt>2.8
    pos=(-11*volt)+86;
else
   pos=(-75.57*volt)+252.37;
end


end