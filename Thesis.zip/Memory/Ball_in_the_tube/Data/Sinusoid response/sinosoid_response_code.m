clear all; close all;
openinout; %Initialisation

Tcycle=0.05;%sampling time

lengthExp=30;%longueur de l'experience

N0=lengthExp/Tcycle; % Nombre de donn�e acquise

%initialisation des matrice ou les donn�es seront stock�e
Data=zeros(N0,2);
DataCommands=zeros(N0,1);


cond=1; %Condition pour rester dans la boucle
i=1; %counter initialisation
value_interval=0:1:N0;
unitstep=value_interval>=0;
ramp=value_interval.*unitstep;
input = 0.5*sin(value_interval/50)+2.4;


%%%%%%%%%sauvegarde des donn�es%%%%%%%%%%%

while cond==1
    tic
    
 anaout(input(i),0); % On applique inputen tension d'entr�e du systeme

    
    
    [in1,in2]=anain; %Anain fonction qui lit les mesures
    
    %Variable ou on stock les donn�es
    Data(i,1)=in1;
    Data(i,2)=in2;
    
    
    DataCommands(i,1)=input(i); 
    
    
    i=i+1;
    t=toc;

    
    
    %%%%%%%Verification du temps de sampling%%%%%%%%    
   
if t>Tcycle
        disp('Sampling time too small');
    else
        while toc<=Tcycle
        end
    end
    
%%%%%% Condition de stop%%%%%%%%%%

    if i==N0+1
        cond=0;
    end
   
end

%%%%%%%%Plot%%%%%%%%%
closeinout
i=i-1;
time=0:Tcycle:(i-1)*Tcycle;

figure

plot(time,Data(:,1),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension [V]');title('Fan velocity for a sinusoid Measurement Gain [2.5V = 1000rpm]'); legend('response','input');


figure
plot(time,Data(:,2),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension [V]');title('Ball position for a sinusoid ');legend('response','input');