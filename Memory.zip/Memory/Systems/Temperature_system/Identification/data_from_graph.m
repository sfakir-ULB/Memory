clear all

a=get(gca,'Children');
%x=get(a,'XData');
y=get(a,'YData');

%xData=cell2mat(x(1));
yData=cell2mat(y(2));
yData_command=cell2mat(y(1));