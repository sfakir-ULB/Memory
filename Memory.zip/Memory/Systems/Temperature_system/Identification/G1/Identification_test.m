opt=stepDataOptions;
opt.StepAmplitude=4;

num=[0 1.087];
den=[289.49 1];
sys=tf(num,den);
k=30;
open_loop=series(k,sys);
closed_loop=feedback(open_loop,1);

figure
step(closed_loop,opt);
