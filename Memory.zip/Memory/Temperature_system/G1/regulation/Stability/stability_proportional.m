opt=stepDataOptions;
opt.StepAmplitude=4;

G_num=[0 1.087];
G_den=[289.49 1];
sys=tf(G_num,G_den);
k=1;
open_loop=series(k,sys);
closed_loop=feedback(open_loop,1);
figure
bode(open_loop);
figure
rlocus(open_loop);

