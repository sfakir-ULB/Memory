clear all; close all;
openinout; %Initialisation

Tcycle=0.1;%sampling time

lengthExp=800;%longueur de l'experience

N0=lengthExp/Tcycle; % Nombre de donn�e acquise

%initialisation des matrice ou les donn�es seront stock�e
Data=zeros(N0,2);
DataCommands=zeros(N0,1);


cond=1; %Condition pour rester dans la boucle
i=1; %counter initialisation
value_interval=(0:4/5999:4);
unitstep=value_interval>=0;
ramp=value_interval.*unitstep;
input = ramp.^2;


%%%%%%%%%sauvegarde des donn�es%%%%%%%%%%%

while cond==1
    tic
    if i<=1000
        anaout(0,0); % On applique 0 V en tension d'entr�e du systeme
    elseif i>=7000 
         anaout(0,0); %on applique une tension d'entr�e de 0V
    else
    anaout(input(i-1000),0); %fonction qui permet d'appliquer la tension desir� dans la carte de sortie 
    end
    
    
    [in1,in2]=anain; %Anain fonction qui lit les mesures
    
    %Variable ou on stock les donn�es
    Data(i,1)=in1;
    Data(i,2)=in2;
    
     if i<=1000
       DataCommands(i,1)=0;
    elseif i>=7000 
         DataCommands(i,1)=0;
    else
    DataCommands(i,1)=input(i-1000); 
    end
    
    i=i+1;
    t=toc;

    
    
    %%%%%%%Verification du temps de sampling%%%%%%%%    
   
if t>Tcycle
        disp('Sampling time too small');
    else
        while toc<=Tcycle
        end
    end
    
%%%%%% Condition de stop%%%%%%%%%%

    if i==N0+1
        cond=0;
    end
    if mod((i*Tcycle),30)==0
        timeElapsed=i*Tcycle
        temperatureSkin=in1
    end
end

%%%%%%%%Plot%%%%%%%%%
closeinout
i=i-1;
time=0:Tcycle:(i-1)*Tcycle;

figure

plot(time,Data(:,1),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension [V]');title('Temperature of the pipe for a curve signal   Measurement Gain [1V = 20�C]'); legend('response','input');


figure
plot(time,Data(:,2),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension [V]');title('Temperature of the air for a curve signal for a curve signal   Measurement Gain [1V = 10�C] ');legend('response','input');