closeinout
