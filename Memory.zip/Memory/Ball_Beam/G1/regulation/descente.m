openinout; %Initialisation

Tcycle=0.05;%sampling time

lengthExp=4;%longueur de l'experience

N0=lengthExp/Tcycle; % Nombre de donn�e acquise


Data=zeros(N0,3); %initialisation des matrice ou les donn�es seront stock�e
DataCommands=zeros(N0,1);


cond=1; %Condition pour rester dans la boucle
i=1; %counter initialisation


input=0; %Initialise input of the inner loop
ref=-5; %valeur du step
K1=1; %Proportional regulateur value 
DataCommands(:)=ref;

actuator=zeros(N0,1);
%%%%%%%%%Loop%%%%%%%%%%%

while cond==1
    tic
    [in1,in2,in3]=anain; %Anain fonction qui lit les mesures
   
    error_inner=ref-in1; %Error inner loop
    input=K1*error_inner;
    
    
    
    
    
    %if input>3 %saturation
        %input=3;
    %elseif input<-1
     %   input=-1;
    %end
    
    
    actuator(i,1)=input;
    %Variable ou on stock les donn�es
    Data(i,1)=in1;
    Data(i,2)=in2;
    Data(i,3)=in3;
    i=i+1;
    t=toc;
%%%%%%%Verification du temps de sampling%%%%%%%%    
   

anaout(input,0); %fonction qui permet d'appliquer la tension desir� dans la carte de sortie 


if t>Tcycle
        disp('Sampling time too small');
    else
        while toc<=Tcycle
        end
    end
    
%%%%%% Condition de stop%%%%%%%%%%

    if i==N0+1
        cond=0;
    end
    
end

%%%%%%%%Plot%%%%%%%%%
closeinout
i=i-1;
time=0:Tcycle:(i-1)*Tcycle;

