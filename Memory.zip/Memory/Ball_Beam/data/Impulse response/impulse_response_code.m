clear all; close all;
openinout; %Initialisation

Tcycle=0.05;%sampling time

lengthExp=15;%longueur de l'experience

N0=lengthExp/Tcycle; % Nombre de donn�e acquise

%initialisation des matrice ou les donn�es seront stock�e
Data=zeros(N0,3);
DataCommands=zeros(N0,1);


cond=1; %Condition pour rester dans la boucle
i=1; %counter initialisation

%%%%%%%%%sauvegarde des donn�es%%%%%%%%%%%

while cond==1
    tic
    if i<100
        anaout(0,0); % On applique 0 V en tension d'entr�e du systeme
    elseif i==100
         anaout(4,0); %on applique une tension d'entr�e de 3V
    else
    anaout(0,0); %fonction qui permet d'appliquer la tension desir� dans la carte de sortie 
    end
    
    
    
    [in1,in2,in3]=anain; %Anain fonction qui lit les mesures
    
    %Variable ou on stock les donn�es
    Data(i,1)=in1;
    Data(i,2)=in2;
    Data(i,3)=in3;
    
     if i<100
       DataCommands(i,1)=0;
    elseif i==100
         DataCommands(i,1)=4;
    else
    DataCommands(i,1)=0; 
    end
    
    i=i+1;
    t=toc;

    
    
    %%%%%%%Verification du temps de sampling%%%%%%%%    
   
if t>Tcycle
        disp('Sampling time too small');
    else
        while toc<=Tcycle
        end
    end
    
%%%%%% Condition de stop%%%%%%%%%%

    if i==N0+1
        cond=0;
    end
    if mod((i*Tcycle),30)==0
        timeElapsed=i*Tcycle
        temperatureSkin=in1
    end
end

%%%%%%%%Plot%%%%%%%%%
closeinout
i=i-1;
time=0:Tcycle:(i-1)*Tcycle;

figure
plot(time,Data(:,1),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension [V] ');title('Motor velocity for a inpulse signal of 4V  Gain Measurement[1V=300pm](2)');legend('response','input');
figure
plot(time,Data(:,2),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension [V] ');title('Beam angle for a impulse signal of 4V Gain Measurement [10V=30�] (2)');legend('response','input');
figure
plot(time,Data(:,3),time,DataCommands(:));
xlabel('Time [sec]');ylabel('Tension [V] ');title('Ball position for a impulse signal of 4V (2)');legend('response','input');