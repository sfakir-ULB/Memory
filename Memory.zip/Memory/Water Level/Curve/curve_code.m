%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Control System Design Lab: Sample Code
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Setup
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

openinout; %Open the ports of the analog computer.

Ts=0.1;%Set the sampling time.

lengthExp=100; %Set the length of the experiment (in seconds).
N0=lengthExp/Ts; %Compute the number of points to save the datas.

Data=zeros(N0,2); %Vector saving the datas. If there are several datas to save, change "1" to the number of outputs.
DataCommands=ones(N0,1); %Vector storing the input sent to the plant.


cond=1; %Set the condition variable to 1.
i=1; %Set the counter to 1.
tic %Begins the first strike of the clock.
time=0:Ts:(N0-1)*Ts; %Vector saving the time steps.

value_interval=(2:1/699:3);
unitstep=value_interval>=0;
ramp=value_interval.*unitstep;
input = ramp.^2;
 %Input of the system.

%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while cond==1
    
    if i<=100
        anaout(0,0); % On applique 2 V en tension d'entr�e du systeme
    elseif i>=800 
         anaout(0,0); %on applique une tension d'entr�e de 8V
    else
    anaout(input(i-100),0); %fonction qui permet d'appliquer la tension desir� dans la carte de sortie 
    end
    
     
    [in1,in2]=anain; %Acquisition of the measurements.
    Data(i,1)=in1;
    Data(i,2)=in2; %Save one of the measurements (in1).
   
    if i<=100
       DataCommands(i,1)=0;
    elseif i>=800 
         DataCommands(i,1)=0;
    else
    DataCommands(i,1)=input(i-100); 
    end
    
    
    
    t=toc; %Second strike of the clock.
    if t>i*Ts
        disp('Sampling time too small');%Test if the sampling time is too small.
    else
        while toc<=i*Ts %Does nothing until the second strike of the clock reaches the sampling time set.
        end
    end
    if i==N0 %Stop condition.
        cond=0;
    end
    i=i+1;
end


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plots
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

closeinout %Close the ports.

figure %Open a new window for plot.
plot(time,Data(:,1),time,DataCommands(:)); 
xlabel('Time [sec]');ylabel('Tension[V]');title('Flow rate for a curve signal (2)');legend('response','input');

figure %Open a new window for plot.
plot(time,Data(:,2),time,DataCommands(:)); 
xlabel('Time [sec]');ylabel('Tension[V]');title('Water level for a curve signal(2)');legend('response','input');