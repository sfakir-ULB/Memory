u=yData_command.';
y=yData_pos;
Ts=0.025;
time=0:Ts:(length(u)-1)*Ts;
offset=150; %Operating point

SystemOrder=[0 1]; %Number of zeros and of poles (0 and 1), respectively.
sysIdent=IdentifySystem(u,y-offset,SystemOrder,Ts);
plot(time,y-offset,'.');
hold on;
lsim(sysIdent,u,time);