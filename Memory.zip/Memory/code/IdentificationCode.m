u=[];
y=[];
for i=10:80
u(i)=yData_command(i).';
y(i)=yData(i);
end

%u=yData.';
%y=yData_2;

Ts=0.05;
time=0:Ts:(length(u)-1)*Ts;
offset=2.5; %Operating point

SystemOrder=[0 1]; %Number of zeros and of poles (0 and 1), respectively.
sysIdent=IdentifySystem(u,y-offset,SystemOrder,Ts);
plot(time,y-offset,'.');
hold on;
lsim(sysIdent,u,time);