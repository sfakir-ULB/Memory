%clear all;
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
yData_command_2=cell2mat(y(1));
yData_2=cell2mat(y(2));