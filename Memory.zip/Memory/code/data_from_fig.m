%clear all;
h = findobj(gca,'Type','line');
y=get(h,'Ydata');
x=get(h,'Xdata');
%yData_command=cell2mat(y(1));
yData=cell2mat(y(2));
%xData=cell2mat(x(1));